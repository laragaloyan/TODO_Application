package com.todo.todo_application;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;


import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    String messageText;
    private ArrayList<String>  mNames = new ArrayList<> ();

            @Override
            public void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);


                initText();

                  FloatingActionButton button;
                button = findViewById(R.id.fab);
                button.setOnClickListener(new View.OnClickListener() {


                    public void onClick(View arg) {
                        Intent intent = new Intent(MainActivity.this, TodoItemActivity.class);
                        startActivityForResult(intent, Intent_Constants.INTENT_REQUEST_CODE);

                    }
                });
            }
//new
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
       if(resultCode == Intent_Constants.INTENT_RESULT_CODE){
        messageText = data.getStringExtra(Intent_Constants.INTENT_MESSAGE_FIELD);
        mNames.add(messageText);
       }
        //TODO
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void initText (){
        mNames.add("Text1");
        mNames.add("Text2");
        mNames.add("Text3");
        mNames.add("Text4");
        mNames.add("Text5");
        mNames.add("Text6");
        mNames.add("Text7");
        mNames.add("Text8");
        mNames.add("Text9");
        mNames.add("Text10");
        initRecyclerView();
    }

    public void initRecyclerView (){
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        ToDoItemActivityAdapter adapter = new ToDoItemActivityAdapter (mNames, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}
