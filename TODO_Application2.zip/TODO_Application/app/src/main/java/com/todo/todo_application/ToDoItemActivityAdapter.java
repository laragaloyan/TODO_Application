package com.todo.todo_application;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ToDoItemActivityAdapter extends RecyclerView.Adapter<ToDoItemActivityAdapter.ToDoItemViewHolder> {

    private ArrayList<String> mData;
    private Context context;



    @NonNull
    @Override
    public ToDoItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.todo_item_view, parent, false);
        return new ToDoItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ToDoItemViewHolder holder, final int position) {
        holder.title.setText(mData.get(position));
        holder.description.setText(mData.get(position));
        holder.date.setText(mData.get(position));

        holder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, mData.get(position), Toast.LENGTH_SHORT).show();
            }
        });
    }



    @Override
    public int getItemCount() {
        return mData.size();
    }

    // constructor
    public ToDoItemActivityAdapter(ArrayList<String> mData, Context context) {
        this.mData = mData;
        this.context = context;
    }

    //View Holder
    public class ToDoItemViewHolder extends RecyclerView.ViewHolder{

     public TextView title;
     public TextView description;
     public TextView date;

     LinearLayout parentLayout;

        public ToDoItemViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title_todo_item_view);
            description = itemView.findViewById(R.id.description_todo_item_view);
            date = itemView.findViewById(R.id.date_todo_item_view);
            parentLayout = itemView.findViewById(R.id.parentLayout);
        }
    }
}
