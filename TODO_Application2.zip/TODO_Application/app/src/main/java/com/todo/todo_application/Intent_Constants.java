package com.todo.todo_application;

public class Intent_Constants {
    public final static String INTENT_MESSAGE_FIELD = "message field";
    public final static int INTENT_RESULT_CODE= 1;
    public final static int INTENT_REQUEST_CODE = 1;
}
